/*
 <!--javascript plugin-->
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/aws-sdk-2.83.0.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/store-2.0.12.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/moment-2.18.1.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/ace-1.2.8.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/aviary-3.1.0.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/medium-editor-5.23.1.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/ag-grid-enterprise-11.0.0.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/alasql-0.4.0.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/xlsx-0.10.8.min.js"></script>

 <!--jquery plugin-->
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/jquery-2.2.4.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/jquery-ui-1.12.1.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/bootstrap-3.3.7.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/slick-1.6.0.min.js"></script>

 <!--angular plugin-->
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-1.6.5.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-1.6.5-animate.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-1.6.5-aria.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-1.6.5-route.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-1.6.5-messages.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-ui-bootstrap-tpls-2.5.0.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-ui-sortable-0.14.4.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-ui-ace-0.2.3.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-ui-tree-2.22.5.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-material-1.1.4.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-material-fileinput-1.5.2.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-slick-3.1.7.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-grid-0.6.5.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/angular-jk-rating-stars-1.0.7.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/ocLazyLoad-1.1.0.min.js"></script>
 <script type="application/javascript" src="https://dazzle-template.s3.amazonaws.com/cdn6.0/js/dazzle-6.0.0.js"></script>

 <!--css style-->
 <link rel="stylesheet" href="https://dazzle-template.s3.amazonaws.com/cdn6.0/css/font-awesome-4.7.0.min.css">
 <link rel="stylesheet" href="https://dazzle-template.s3.amazonaws.com/cdn6.0/css/medium-editor-5.23.1.min.css">
 <link rel="stylesheet" href="https://dazzle-template.s3.amazonaws.com/cdn6.0/css/jquery-ui-1.12.1.min.css">
 <link rel="stylesheet" href="https://dazzle-template.s3.amazonaws.com/cdn6.0/css/bootstrap-3.3.7.min.css">
 <link rel="stylesheet" href="https://dazzle-template.s3.amazonaws.com/cdn6.0/css/slick-1.6.0.min.css">
 <link rel="stylesheet" href="https://dazzle-template.s3.amazonaws.com/cdn6.0/css/slick-1.6.0-theme.min.css">
 <link rel="stylesheet" href="https://dazzle-template.s3.amazonaws.com/cdn6.0/css/angular-material-1.1.4.min.css">
 <link rel="stylesheet" href="https://dazzle-template.s3.amazonaws.com/cdn6.0/css/angular-material-fileinput-1.5.2.min.css">
 <link rel="stylesheet" href="https://dazzle-template.s3.amazonaws.com/cdn6.0/css/angular-jk-rating-stars-1.0.7.min.css">
 <link rel="stylesheet" href="https://dazzle-template.s3.amazonaws.com/cdn6.0/css/angular-ui-tree-2.22.5.min.css">

 */
agGrid.LicenseManager.setLicenseKey("ag-Grid_Evaluation_License_Not_for_Production_100Devs21_June_2017__MTQ5Nzk5OTYwMDAwMA==896e8af7accaf15a04ddf6b6577c55c8");
agGrid.initialiseAgGridWithAngular1(angular);

// var QueryString = function () {
//     var query_string = {};
//     var query = window.location.search.substring(1);
//     var vars = query.split("&&&");
//     for (var i = 0; i < vars.length; i++) {
//         var pair = vars[i].split(":===:");
//         if (typeof query_string[pair[0]] === "undefined") {
//             query_string[pair[0]] = decodeURIComponent(pair[1]);
//         } else if (typeof query_string[pair[0]] === "string") {
//             var arr = [query_string[pair[0]], decodeURIComponent(pair[1])];
//             query_string[pair[0]] = arr;
//         } else {
//             query_string[pair[0]].push(decodeURIComponent(pair[1]));
//         }
//     }
//     return query_string;
// }();

angular.module('dazzle',[]);


//var dazzle = angular.module('dazzle', ['ngRoute', 'ngMessages', 'ngMaterial'
    //, 'agGrid', 'angularGrid', 'ui.bootstrap', 'ui.tree', 'ui.ace', 'ui.sortable', 'oc.lazyLoad'
 //   , 'slickCarousel', 'lfNgMdFileInput', 'jkAngularRatingStars'
 //]);
// dazzle.config(function ($sceDelegateProvider) {
//     $sceDelegateProvider.resourceUrlWhitelist([
//         'self',
//         'https://s3-ap-southeast-1.amazonaws.com/**',
//         'http://s3-ap-southeast-1.amazonaws.com/**',
//         'https://s3-ap-northeast-1.amazonaws.com/**',
//         'http://s3-ap-northeast-1.amazonaws.com/**',
//         'https://dazzle-template.s3.amazonaws.com/**',
//         'http://dazzle-template.s3.amazonaws.com/**'
//     ]);
// });
// dazzle.service('$dazzleS3', function () {
//     var that = this;
//     this.getJson = function (bucket, key) {
//         return new Promise(function (resolve, reject) {
//             var s3 = new AWS.S3();
//             var params = {
//                 Bucket: bucket,
//                 Key: key,
//                 ResponseExpires: new Date().getTime()
//             };
//             s3.getObject(params, function (err, data) {
//                 if (err) {
//                     reject(err);
//                 } else {
//                     try {
//                         resolve(JSON.parse(data.Body.toString()));
//                     } catch (e) {
//                         reject();
//                     }
//                 }
//             });
//         });
//     }

//     this.saveJson = function (bucket, key, json) {
//         return new Promise(function (resolve, reject) {
//             var s3 = new AWS.S3();
//             var params = {
//                 Bucket: bucket,
//                 Key: key,
//                 ContentType: "application/json",
//                 Body: JSON.stringify(json, null, 4)
//             }
//             s3.putObject(params, function (err, data) {
//                 if (err) {
//                     reject(err);
//                 } else {
//                     resolve(data);
//                 }
//             });
//         })
//     }

//     this.getFile = function (bucket, key) {
//         return new Promise(function (resolve, reject) {
//             var s3 = new AWS.S3();
//             var params = {
//                 Bucket: bucket,
//                 Key: key,
//                 ResponseExpires: new Date().getTime()
//             };
//             s3.getObject(params, function (err, data) {
//                 if (err) {
//                     reject(err);
//                 } else {
//                     resolve(data.Body.toString());
//                 }
//             });
//         });
//     }

//     this.saveFile = function (bucket, key, string) {
//         return new Promise(function (resolve, reject) {
//             var s3 = new AWS.S3();
//             var params = {
//                 Bucket: bucket,
//                 Key: key,
//                 Body: string
//             }

//             var ext = key.substr(key.lastIndexOf('.') + 1);
//             if (ext === 'css') {
//                 params.ContentType = 'text/css';
//             } else if (ext === 'less') {
//                 params.ContentType = 'text/css';
//             } else if (ext === 'js') {
//                 params.ContentType = 'application/javascript';
//             } else if (ext === 'json') {
//                 params.ContentType = 'application/json';
//             } else if (ext === 'jpg') {
//                 params.ContentType = 'image/jpeg';
//             } else if (ext === 'jpeg') {
//                 params.ContentType = 'image/jpeg';
//             } else if (ext === 'png') {
//                 params.ContentType = 'image/png';
//             } else if (ext === 'gif') {
//                 params.ContentType = 'image/gif';
//             }

//             s3.putObject(params, function (err, data) {
//                 if (err) {
//                     reject(err);
//                 } else {
//                     resolve(data);
//                 }
//             });
//         });
//     }

//     this.saveImage = function (uid, file) {
//         return new Promise(function (resolve, reject) {
//             var s3 = new AWS.S3();
//             var oldFilename = encodeURIComponent(file.name);
//             var fileExtansion = oldFilename.split('.').pop();
//             var newFilename = 'id' + new Date().getTime() + '.jpg';
//             var params = {
//                 Bucket: "designerrrr",
//                 Key: "images/" + uid + "/" + newFilename,
//                 ContentType: file.type,
//                 Body: file,
//                 Metadata: {
//                     "newVersion": "new",
//                     "gid": newFilename,
//                     "owner_id": uid,
//                     "original_name": oldFilename,
//                     "galleryType": "photo"
//                 }
//             };
//             s3.putObject(params, function (err, data) {
//                 if (err) {
//                     reject(err);
//                 } else {
//                     resolve({
//                         "oldFilename": oldFilename,
//                         "newFilename": newFilename,
//                         "fileExtansion": fileExtansion,
//                         "fileType": file.type
//                     });
//                 }
//             });
//         });
//     }

//     this.listObject = function (bucket, key) {
//         return new Promise(function (resolve, reject) {
//             var s3 = new AWS.S3();
//             var params = {
//                 Bucket: bucket,
//                 Prefix: key
//             };
//             s3.listObjects(params, function (err, data) {
//                 if (err) {
//                     reject(err);
//                 } else {
//                     resolve(data.Contents);
//                 }
//             });
//         });
//     }

//     this.copyFile = function (copySource, bucket, key) {
//         return new Promise(function (resolve, reject) {
//             var s3 = new AWS.S3();
//             var params = {
//                 Bucket: bucket,
//                 Key: key,
//                 CopySource: encodeURIComponent(copySource)
//             }
//             s3.copyObject(params, function (err, data) {
//                 if (err) {
//                     reject(err);
//                 } else {
//                     resolve(data);
//                 }
//             });
//         });
//     }

//     this.checkFile = function (bucket, key) {
//         return new Promise(function (resolve, reject) {
//             var s3 = new AWS.S3();
//             var params = {
//                 Bucket: bucket,
//                 Key: key
//             };
//             s3.headObject(params, function (err, data) {
//                 if (err) {
//                     resolve(false)
//                 } else {
//                     resolve(true);
//                 }
//             });
//         });
//     }

//     this.getFileUrl = function (bucket, key, expires) {
//         return new Promise(function (resolve, reject) {
//             var s3 = new AWS.S3();
//             var params = {
//                 "Bucket": bucket,
//                 "Key": key
//             };
//             if (expires) {
//                 params.Expires = expires;
//             }
//             s3.getSignedUrl('getObject', params, function (err, url) {
//                 if (err) {
//                     reject(err);
//                 } else {
//                     resolve(url);
//                 }
//             });
//         })
//     }

// });
// dazzle.service('$dazzlePopup', function ($mdDialog, $mdBottomSheet, $mdToast, $ocLazyLoad) {
//     var that = this;
//     this.question = function (title, text, yText, nText) {
//         return new Promise(function (resolve, reject) {
//             var confirm = $mdDialog.confirm()
//                 .title(title)
//                 .textContent(text)
//                 .ariaLabel('question')
//                 .multiple(true)
//                 .ok(yText)
//                 .cancel(nText);

//             $mdDialog.show(confirm).then(function () {
//                 resolve();
//             }, function () {
//                 reject();
//             });
//         });
//     }
//     this.toast = function (text) {
//         $mdToast.show(
//             $mdToast.simple()
//                 .position('top right')
//                 .textContent(text)
//                 .hideDelay(1500)
//         );
//     }
//     this.alert = function (title, text) {
//         return new Promise(function (resolve, reject) {
//             $mdDialog.show(
//                 $mdDialog.alert()
//                     .escapeToClose(false)
//                     .clickOutsideToClose(false)
//                     .title(title)
//                     .textContent(text)
//                     .ok('OK')
//             ).then(function () {
//                 resolve();
//             });
//         });
//     };
//     this.loading = function () {
//         var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/loadingPopup/popup.html" + "?id=" + new Date().getTime();
//         var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/loadingPopup/popup.js" + "?id=" + new Date().getTime();
//         $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//             $mdDialog.show({
//                 templateUrl: templateUrl,
//                 controller: loadingPopupController,
//                 clickOutsideToClose: false,
//                 fullscreen: false
//             });
//         });
//     }
//     this.login = function () {
//         return new Promise(function (resolve, reject) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/loginPopup/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/loginPopup/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
//                     controller: loginPopupController,
//                     clickOutsideToClose: false,
//                     escapeToClose: false,
//                     multiple: true
//                 }).then(function (user) {
//                     resolve(user);
//                 }, function () {
//                     reject();
//                 });
//             });
//         });
//     }
//     this.recharge = function () {
//         var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/rechargePopup/popup.html" + "?id=" + new Date().getTime();
//         var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/rechargePopup/popup.js" + "?id=" + new Date().getTime();
//         $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//             $mdDialog.show({
//                 templateUrl: templateUrl,
//                 controller: rechargePopupController
//             });
//         });
//     }
//     this.sellWebsite = function (website) {
//         if (website) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/sellWebsitePopup/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/sellWebsitePopup/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
//                     controller: sellWebsitePopupController,
//                     locals: {
//                         website: website
//                     }
//                 });
//             });
//         }
//     }
//     this.websiteSetting = function (websiteId) {
//         if (websiteId) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/websiteSettingPopup/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/websiteSettingPopup/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
//                     controller: websiteSettingPopupController,
//                     locals: {
//                         websiteId: websiteId
//                     }
//                 });
//             });
//         }
//     }
//     this.photoDetail = function (gid, type) {
//         if (!type) {
//             type = "photo";
//         }
//         if (gid) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/photoDetailPopup/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/photoDetailPopup/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
//                     controller: photoDetailPopupController,
//                     locals: {
//                         gid: gid,
//                         type: type
//                     }
//                 });
//             });
//         }
//     }
//     this.websiteDetail = function (wid, website) {
//         if (wid) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/websiteDetailPopup/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/websiteDetailPopup/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
//                     controller: websiteDetailPopupController,
//                     locals: {
//                         wid: wid,
//                         website: website || null
//                     }
//                 });
//             });
//         }
//     }
//     this.buyDomain = function () {
//         return new Promise(function (resolve, reject) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/buyDomainPopup/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/buyDomainPopup/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
//                     controller: buyDomainPopupController,
//                     multiple: true
//                 });
//             }).then(function (domain) {
//                 resolve(domain);
//             }, function () {
//                 reject();
//             });
//         });
//     }

//     this.formView = function (headerJson,formJson) {
//         return new Promise(function (resolve, reject) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/formViewPopup/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/formViewPopup/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
//                     controller: formViewPopupController,
//                     multiple: true,
//                     locals: {
//                         headerJson: headerJson,
//                         formJson: formJson
//                     }
//                 }).then(function (ele) {
//                     resolve(ele);
//                 }, function () {
//                     reject();
//                 });
//             });
//         });
//     }

//     this.popupCall = function(functionName,scope){
//         return new Promise(function (resolve, reject) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/"+functionName+"/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/"+functionName+"/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
// //                    controller: eval(functionName+"Controller"),
//                     controller: "exportPopupController",
//                     multiple: true,
//                     clickOutsideToClose: true,
//                     locals: {
//                         rootScope: scope
//                     }
//                 }).then(function (ele) {
//                     console.log('Dazzle popupCall', ele);
//                     resolve(ele);
//                 }, function () {
//                     reject();
//                 });
//             });
//         });

//     }

//     this.addElement = function (scope) {
//         return new Promise(function (resolve, reject) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/addElementPopup/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/addElementPopup/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
//                     controller: addElementPopupController,
//                     multiple: true,
//                     locals: {
//                         rootScope: scope
//                     }
//                 }).then(function (ele) {
//                     console.log('Dazzle Add Element', ele);
//                     resolve(ele);
//                 }, function () {
//                     reject();
//                 });
//             });
//         });
//     }

//     this.dataAddSelect = function (website, table) {
//         return new Promise(function (resolve, reject) {
//             if (website && table) {
//                 var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/dataSelectPopup/addselect.html" + "?id=" + new Date().getTime();
//                 var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/dataSelectPopup/popup.js" + "?id=" + new Date().getTime();
//                 $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                     $mdBottomSheet.show({
//                         templateUrl: templateUrl,
//                         controller: addSelectPopupController,
//                         multiple: true,
//                         clickOutsideToClose: true,
// //                        parent:angular.element('#data-select'),                        
//                         locals: {
//                             website: website,
//                             table: table,
//                             filter: null
//                         }
//                     }).then(function (data) {
//                         resolve(data);
//                     }, function () {
//                         reject();
//                     });
//                 });
//             } else {
//                 reject();
//             }
//         });
//     }

//     this.dataSelect = function (website, table,filter) {
//         return new Promise(function (resolve, reject) {
//             if (website && table) {
//                 var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/dataSelectPopup/popup.html" + "?id=" + new Date().getTime();
//                 var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/dataSelectPopup/popup.js" + "?id=" + new Date().getTime();
//                 $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                     $mdDialog.show({
//                         templateUrl: templateUrl,
//                         controller: dataSelectPopupController,
//                         multiple: true,
//                         clickOutsideToClose: true,
// //                        parent:angular.element('#data-management'),
//                         locals: {
//                             website: website,
//                             table: table,
//                             filter: filter
//                         }
//                     }).then(function (data) {
//                         resolve(data);
//                     }, function () {
//                         reject();
//                     });
//                 });
//             } else {
//                 reject();
//             }
//         });
//     }
//     this.dataManagement = function (website, table, filter, isForm) {
//         return new Promise(function (resolve, reject) {
//             if (website && table) {
//                 var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/dataManagementPopup/popup.html" + "?id=" + new Date().getTime();
//                 var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/dataManagementPopup/popup.js" + "?id=" + new Date().getTime();
//                 $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                     $mdDialog.show({
//                         templateUrl: templateUrl,
//                         controller: dataManagementPopupController,
//                         multiple: true,
//                         locals: {
//                             website: website,
//                             table: table,
//                             filter: filter || null,
//                             isForm: isForm || "normal"
//                         }
//                     }).then(function (data) {
//                         resolve(data);
//                     }, function () {
//                         resolve();
//                     });
//                 });
//             } else {
//                 reject();
//             }
//         });
//     }

//     this.schema = function (website, table, isForm) {
//         return new Promise(function (resolve, reject) {
//             if (website && table) {
//                 var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/editSchemaPopup/popup.html" + "?id=" + new Date().getTime();
//                 var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/editSchemaPopup/popup.js" + "?id=" + new Date().getTime();
//                 $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                     $mdDialog.show({
//                         templateUrl: templateUrl,
//                         controller: editSchemaPopupController,
//                         clickOutsideToClose: false,
//                         escapeToClose: false,
//                         multiple: true,
//                         locals: {
//                             website: website,
//                             table: table,
//                             isForm: isForm
//                         }
//                     }).then(function (json) {
//                         resolve(json);
//                     }, function () {
//                         reject();
//                     });
//                 });
//             } else {
//                 reject();
//             }
//         });
//     }
//     this.code = function (code, type) {
//         return new Promise(function (resolve, reject) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/editCodePopup/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/editCodePopup/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
//                     controller: editCodePopupController,
//                     clickOutsideToClose: false,
//                     escapeToClose: false,
//                     multiple: true,
//                     locals: {
//                         code: code,
//                         type: type
//                     }
//                 }).then(function (newCode) {
//                     resolve(newCode);
//                 }, function () {
//                     reject();
//                 });
//             });
//         });
//     }
//     this.html = function (html) {
//         return new Promise(function (resolve, reject) {
//             var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/editHtmlPopup/popup.html" + "?id=" + new Date().getTime();
//             var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/editHtmlPopup/popup.js" + "?id=" + new Date().getTime();
//             $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                 $mdDialog.show({
//                     templateUrl: templateUrl,
//                     controller: editHtmlPopupController,
//                     clickOutsideToClose: false,
//                     escapeToClose: false,
//                     multiple: true,
//                     locals: {
//                         html: html
//                     }
//                 }).then(function (newHtml) {
//                     resolve(newHtml);
//                 }, function () {
//                     reject();
//                 });
//             });
//         });
//     }
//     this.tag = function (tags, allTags) {
//         return new Promise(function (resolve, reject) {
//             if (tags) {
//                 var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/editTagsPopup/popup.html" + "?id=" + new Date().getTime();
//                 var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/editTagsPopup/popup.js" + "?id=" + new Date().getTime();
//                 $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                     $mdDialog.show({
//                         templateUrl: templateUrl,
//                         controller: editTagsPopupController,
//                         clickOutsideToClose: false,
//                         escapeToClose: false,
//                         multiple: true,
//                         locals: {
//                             tags: tags,
//                             allTags: allTags || []
//                         }
//                     }).then(function (newTags) {
//                         resolve(newTags);
//                     }, function () {
//                         reject();
//                     });
//                 });
//             } else {
//                 reject();
//             }
//         });
//     }
//     this.gallery = function (images) {
//         return new Promise(function (resolve, reject) {
//             if (images) {
//                 var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/editGalleryPopup/popup.html" + "?id=" + new Date().getTime();
//                 var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/editGalleryPopup/popup.js" + "?id=" + new Date().getTime();
//                 $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                     $mdDialog.show({
//                         templateUrl: templateUrl,
//                         controller: editGalleryPopupController,
//                         clickOutsideToClose: false,
//                         escapeToClose: false,
//                         multiple: true,
//                         locals: {
//                             images: images
//                         }
//                     }).then(function (newImages) {
//                         resolve(newImages);
//                     }, function () {
//                         reject();
//                     });
//                 });
//             } else {
//                 reject();
//             }
//         });
//     }
//     this.uploadImage = function (uid) {
//         return new Promise(function (resolve, reject) {
//             if (uid) {
//                 var templateUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/uploadImagePopup/popup.html" + "?id=" + new Date().getTime();
//                 var controllerUrl = "https://dazzle-template.s3.amazonaws.com/cdn6.0/models/uploadImagePopup/popup.js" + "?id=" + new Date().getTime();
//                 $ocLazyLoad.load([controllerUrl], {cache: false}).then(function () {
//                     $mdDialog.show({
//                         templateUrl: templateUrl,
//                         controller: uploadImageController,
//                         clickOutsideToClose: false,
//                         escapeToClose: false,
//                         multiple: true,
//                         locals: {
//                             uid: uid
//                         }
//                     }).then(function (uploadedFiles) {
//                         resolve(uploadedFiles);
//                     }, function () {
//                         reject();
//                     });
//                 });
//             } else {
//                 reject();
//             }
//         });
//     }
// });
// dazzle.service('$dazzleUser', function ($http, $interval) {
//     var that = this;
//     var user = store.get('user') || null;

//     this.setUser = function (u) {
//         if (u && u.key && u.key.AccessKeyId && u.key.SecretAccessKey && u.key.SessionToken) {
//             AWS.config = new AWS.Config();
//             AWS.config.accessKeyId = u.key.AccessKeyId;
//             AWS.config.secretAccessKey = u.key.SecretAccessKey;
//             AWS.config.sessionToken = u.key.SessionToken;
//             AWS.config.region = 'ap-northeast-1';
//         } else {
//             AWS.config.accessKeyId = null;
//             AWS.config.secretAccessKey = null;
//             AWS.config.sessionToken = null;
//             AWS.config.region = null;
//         }
//         user = u;
//         store.set('user', u);
//     }

//     this.getUser = function () {
//         return user;
//     }

//     this.userLogin = function (data) {
//         return new Promise(function (resolve, reject) {
//             $http({
//                 "method": "post",
//                 "url": "https://37nolo3390.execute-api.ap-northeast-1.amazonaws.com/prod",
//                 "data": data
//             }).then(function (result) {
//                 if (result.data.code > 0) {
//                     that.setUser(result.data.user);
//                     resolve();
//                 } else {
//                     that.setUser(null);
//                     reject();
//                 }
//             });
//         });
//     }

//     if (user && user.key && user.key.Expiration) {
//         that.setUser(user);
//     }

//     $interval(function () {
//         if (user && user.key && user.key.Expiration) {
//             var now = new Date();
//             var expired = new Date(user.key.Expiration);
//             if (expired < now) {
//                 store.clearAll();
//                 window.location = "http://dazzle.website/";
//             }
//         }
//     }, 1000);

// });
// dazzle.service("$dazzleFn", function ($dazzleS3) {
//     var that = this;
//     this.getUserTables = function (userId, websiteId) {
//         return new Promise(function (resolve, reject) {
//             var tables = [];
//             if (userId, websiteId) {
//                 $dazzleS3.listObject('dazzle-user-' + userId, 'website/' + websiteId + '/content/').then(function (files) {
//                     for (var i = 0; i < files.length; i++) {
//                         var file = files[i].Key.split('\\').pop().split('/').pop();
//                         if (file && file.length > 0) {
//                             var filename = file.split('.')[0];
//                             var fileExtension = file.split('.')[1];
//                             if (filename && filename.length > 0) {
//                                 var isTable = filename.endsWith('-table');
//                                 if (isTable) {
//                                     var tableName = filename.replace('-table', "");
//                                     if (tableName && tables.indexOf(tableName) < 0 && tableName !== 'undefined' && tableName !== 'null') {
//                                         tables.push(tableName);
//                                     }
//                                 }
//                             }
//                         }
//                     }
//                     resolve(tables);
//                 }, function () {
//                     reject();
//                 });
//             } else {
//                 reject();
//             }
//         });
//     }
//     this.getTableTable = function (userId, websiteId, tableName) {
//         return new Promise(function (resolve, reject) {
//             $dazzleS3.getJson('dazzle-user-' + userId, 'website/' + websiteId + '/content/' + tableName + '-table.json').then(function (json) {
//                 resolve(json);
//             }, function () {
//                 reject();
//             });
//         });
//     }
//     this.getTableSchema = function (userId, websiteId, tableName) {
//         return new Promise(function (resolve, reject) {
//             $dazzleS3.getJson('dazzle-user-' + userId, 'website/' + websiteId + '/content/' + tableName + '-schema.json').then(function (json) {
//                 resolve(json);
//             }, function () {
//                 reject();
//             });
//         });
//     }
// });

// dazzle.service("$dazzleData", function ($window, $http, $compile, $uibModal, $mdDialog, $mdToast, $mdBottomSheet, $ocLazyLoad, $mdDateLocale, $dazzleS3, $dazzlePopup, $dazzleUser, $dazzleFn) {

//     scope = this;
//     scope.$http = $http;
//     scope.$window = $window;
//     scope.$compile = $compile;
//     scope.$uibModal = $uibModal;
//     scope.$mdDialog = $mdDialog;
//     scope.$mdToast = $mdToast;
//     scope.$mdBottomSheet = $mdBottomSheet;
//     scope.$ocLazyLoad = $ocLazyLoad;
//     scope.$mdDateLocale = $mdDateLocale;
//     scope.$dazzleS3 = $dazzleS3;
//     scope.$dazzlePopup = $dazzlePopup;
//     scope.$dazzleUser = $dazzleUser;
//     scope.$dazzleFn = $dazzleFn;
// //    scope.website = website;
// //    scope.table = table;
//     // scope.isForm = false;
//     // scope.editable = true;
//     // scope.modelType = isForm;


//     scope.user = $dazzleUser.getUser();
    
//     console.log(scope.user);


//     scope.init = function (website,table,filter) {
//         console.log('Init Data');
//         scope.inited = false;
//         scope.website = website;
//         scope.table = table;
//         scope.filter = filter || null;
//         console.log(scope.website);
//         console.log(scope.table);
//         scope.getWebsiteJson();
//         scope.lastUpdated = null;
//         scope.gridOptions = {
//             rowSelection: 'multiple',
//             rowHeight: 45,
//             animateRows: true,
//             floatingFilter: true,
//             angularCompileRows: true,
//             enableColResize: true,
//             enableFilter: true,
//             enableSorting: true,
//             isExternalFilterPresent: function () {
//                 return true;
//             },
//             doesExternalFilterPass: function (node) {
//                 if (node.deleted) {
//                     return false;
//                 } else {
//                     if (scope.filter) {
//                         if (scope.filter.data.indexOf(node.data[filter.key]) < 0) {
//                             return false;
//                         } else {
//                             return true;
//                         }
//                     }
//                     return true;
//                 }
//             },
//             defaultColDef: {
//                 headerCheckboxSelection: scope.isFirstColumn,
//                 checkboxSelection: scope.isFirstColumn,
//                 editable: true,
//                 cellEditor: "text",
//                 filter: 'text'
//             },
//             onGridReady: function () {
//                 scope.loadTable().then(function (table) {
//                     scope.tableJson = table;
//                     if (angular.isArray(scope.tableJson.buttons)) {
//                         for (var i = 0; i < scope.tableJson.buttons.length; i++) {
//                             scope.loadButton(scope.tableJson.buttons[i]);
//                         }
//                     }
//                     scope.loadSchema().then(function (json) {
//                         scope.schemaJson = json;
//                         scope.loadCell(json).then(function () {
//                             console.log('Column JSON',json);
//                             if (!scope.editable)
//                                 angular.forEach(json,function(item,index){
//                                     json[index].editable=false;
//                                 });
//                             scope.gridOptions.api.setColumnDefs(json);
//                             scope.gridOptions.api.refreshView();
//                             scope.loadData().then(function (json) {
//                                 scope.gridOptions.api.setRowData(json);
//                                 scope.gridOptions.api.refreshView();
//                                 scope.inited = true;
//                                 console.log('Table:', scope.tableJson);
//                                 console.log('Schema:', scope.schemaJson);
//                                 console.log('Data:', json);
//                             });
//                         });
//                     });
//                 });
//             },
//             onCellEditingStarted: function (event) {
//                 event.scope.oldValue = event.value;
//             },
//             onCellEditingStopped: function (event) {
//                 if (!angular.isUndefined(event.colDef.key) && event.colDef.key) {
//                     scope.gridOptions.api.forEachNode(function (rowNode, index) {
//                         if (rowNode.data[event.colDef.field] == event.value && rowNode.rowIndex !== event.rowIndex) {
//                             event.scope.rowNode.setDataValue(event.colDef.field, event.scope.oldValue);
//                             $dazzlePopup.toast('ERROR: Key already exists');
//                             return;
//                         }
//                     });
//                 }
//                 if (!angular.isUndefined(event.colDef.required) && event.colDef.required) {
//                     if (!event.value) {
//                         event.scope.rowNode.setDataValue(event.colDef.field, event.scope.oldValue);
//                         $dazzlePopup.toast('ERROR: scope is required');
//                     }
//                 }
//                 if (scope.filter) {
//                     scope.gridOptions.api.onFilterChanged();
//                 }
//             },
//             onCellFocused: function (event) {
//                 if (event.rowIndex !== null) {
//                     scope.gridOptions.api.getModel().rowsToDisplay[event.rowIndex].edited = true;
//                 }
//             }
//         }
//     }

//     scope.getWebsiteJson = function () {
//         $dazzleS3.getJson("dazzle-user-" + scope.user.uid, "website/" + scope.website + '/json/website.json').then(function (json) {
//             scope.websiteJson = json;
//         });
//     }

//     scope.loadButton = function (b) {
//         $ocLazyLoad.load({files: b.js, cache: false}).then(function () {
//             var button = angular.element(b.html);
//             angular.element('#customButtons').append(button);
//             $compile(button)(scope);
//         });
//     }


//     scope.editSchema = function () {
//         $dazzlePopup.schema(scope.website, scope.table, scope.isForm).then(function (newSchema) {
//             $dazzleS3.saveJson('dazzle-user-' + $dazzleUser.getUser().uid, 'website/' + scope.website + '/' + "content/" + scope.table + "-schema.json", JSON.parse(angular.toJson(newSchema)));
//             scope.schemaJson = newSchema;
//             scope.loadCell(newSchema).then(function () {
//                 scope.gridOptions.api.setColumnDefs(newSchema);
//                 scope.gridOptions.api.refreshView();
//             });
//         });
//     }

//     scope.loadTable = function () {
//         return new Promise(function (resolve, reject) {
//             $dazzleS3.getJson('dazzle-user-' + $dazzleUser.getUser().uid, 'website/' + scope.website + '/' + "content/" + scope.table + "-table.json").then(function (json) {
//                 if (json.data && json.data.type && json.data.type === 'dynamodb') {
//                     if (json.data.table && json.data.key) {
//                         scope.checkDynamoTable(json.data.table).then(function (dynamodb) {
//                             resolve(json);
//                         }, function (text) {
//                             $dazzlePopup.toast("DynamoDB:" + text);
//                             reject();
//                         });
//                     } else if (!json.data.table) {
//                         $dazzlePopup.toast('ERROR: 沒有設定Table');
//                         reject();
//                     } else if (!json.data.key) {
//                         $dazzlePopup.toast('ERROR: 沒有設定Key');
//                         reject();
//                     }
//                 } else if (json.data && json.data.type && json.data.type === 's3') {
//                     resolve(json);
//                 } else {
//                     scope.initTable().then(function (t) {
//                         resolve(t);
//                     })
//                 }
//             }, function () {
//                 scope.initTable().then(function (t) {
//                     resolve(t);
//                 });
//             });
//         });
//     }

//     scope.initTable = function () {
//         return new Promise(function (resolve, reject) {
//             $dazzlePopup.toast('正在初始化s3 Table:' + scope.table);
//             var table = {
//                 "data": {
//                     "type": "s3"
//                 },
//                 "buttons": []
//             }
//             $dazzleS3.saveJson('dazzle-user-' + $dazzleUser.getUser().uid, "website/" + website + "/content/" + scope.table + "-table.json", table);
//             resolve(table);
//         });
//     }

//     scope.checkDynamoTable = function (table) {
//         return new Promise(function (resolve, reject) {
//             $http({
//                 "method": "post",
//                 "url": "https://j96d5s2sme.execute-api.ap-northeast-1.amazonaws.com/prod/check",
//                 "data": {
//                     "action": "checkDynamoTable",
//                     "table": table
//                 }
//             }).then(function (result) {
//                 if (result.data.code == 14) {
//                     resolve(result.data.data);
//                 } else {
//                     reject(result.data.text);
//                 }
//             })
//         });
//     }

//     scope.loadSchema = function () {
//         return new Promise(function (resolve, reject) {
//             $dazzleS3.getJson('dazzle-user-' + $dazzleUser.getUser().uid, "website/" + scope.website + "/content/" + scope.table + "-schema.json").then(function (json) {
//                 resolve(json);
//             }, function () {
//                 $dazzleS3.saveJson('dazzle-user-' + $dazzleUser.getUser().uid, "website/" + scope.website + "/content/" + scope.table + "-schema.json", []);
//                 resolve([]);
//             });
//         });
//     };

//     scope.loadData = function () {
//         return new Promise(function (resolve, reject) {
//             if (scope.tableJson.data.type === 's3') {
//                 console.log('Load S3 Data');
//                 $dazzleS3.getJson('dazzle-user-' + $dazzleUser.getUser().uid, "website/" + scope.website + "/content/" + scope.table + "-data.json").then(function (json) {
//                     resolve(json);
//                 }, function () {
//                     $dazzleS3.saveJson('dazzle-user-' + $dazzleUser.getUser().uid, "website/" + scope.website + "/content/" + scope.table + "-data.json", []);
//                     resolve([]);
//                 });
//             } else if (scope.tableJson.data.type === 'dynamodb') {
//                 console.log('Load DynamoDB Data');
//                 $http({
//                     "method": "post",
//                     "url": "https://j96d5s2sme.execute-api.ap-northeast-1.amazonaws.com/prod/dynamodb",
//                     "data": {
//                         "action": "scanTable",
//                         "table": scope.tableJson.data.table,
//                         "awsKey": scope.user.key
//                     }
//                 }).then(function (result) {
//                     if (result.data.code < 0) {
//                         $dazzlePopup.toast(result.data.text + ":" + result.data.err.code);
//                         reject();
//                     } else {
//                         resolve(result.data.data);
//                     }
//                 });
//                 $http({
//                     "method": "post",
//                     "url": "https://j96d5s2sme.execute-api.ap-northeast-1.amazonaws.com/prod/dynamodb",
//                     "data": {
//                         "action": "backupDynamodbTable",
//                         "table": scope.tableJson.data.table,
//                         "awsKey": scope.user.key
//                     }
//                 })
//             } else {
//                 $dazzlePopup.toast("未知數據來源");
//                 resolve([]);
//             }
//         });
//     };

//     scope.loadCell = function (schema) {
//         return new Promise(function (resolve, reject) {
//             for (var i = 0; i < schema.length; i++) {
//                 if (!angular.isUndefined(schema[i].jsId)) {
//                     scope.setCellJs(schema[i]);
//                 }
//                 if (!angular.isUndefined(schema[i].cellEditor)) {
//                     scope.setCellEditor(schema[i]);
//                 }
//                 if (!angular.isUndefined(schema[i].cellRenderer)) {
//                     scope.setCellRenderer(schema[i]);
//                 }
//                 if (!angular.isUndefined(schema[i].cellFilter)) {
//                     scope.setCellFilter(schema[i]);
//                 }
//             }
//             setTimeout(function () {
//                 resolve();
//             }, 1000);
//         });
//     }

//     scope.setCellJs = function (schema) {
//         $ocLazyLoad.load("https://dazzle-template.s3.amazonaws.com/backend6.0/" + schema.directive + "/js/" + schema.jsId + '.js', {cache: false});
//     }

//     scope.setCellFilter = function (schema) {
//         $ocLazyLoad.load("https://dazzle-template.s3.amazonaws.com/backend6.0/" + schema.directive + "/" + schema.cellFilter + ".js", {cache: false}).then(function () {
//             schema.filterParams = window[schema.cellFilter];
//         });
//     }

//     scope.setCellEditor = function (schema) {
//         $ocLazyLoad.load("https://dazzle-template.s3.amazonaws.com/backend6.0/" + schema.directive + "/" + schema.cellEditor + ".js", {cache: false}).then(function () {
//             scope.gridOptions.api.cellEditorFactory.addCellEditor(schema.cellEditor, window[schema.cellEditor]);
//         });
//     }

//     scope.setCellRenderer = function (schema) {
//         $ocLazyLoad.load("https://dazzle-template.s3.amazonaws.com/backend6.0/" + schema.directive + "/" + schema.cellRenderer + ".js", {cache: false}).then(function () {
//             scope.gridOptions.api.cellRendererFactory.addCellRenderer(schema.cellRenderer, window[schema.cellRenderer]);
//         });
//     }


//     scope.referAdd = function(object){
//             console.log('Open Data Select');
//             $dazzlePopup.dataSelect(scope.website, scope.table).then(function (data) {

//             });

//     }

//     scope.addFilter = function(filter){
//                 this.filter = filter;
//                 this.gridOptions.api.onFilterChanged();
//     }

//     scope.add = function (object) {
//             var date = new Date().getTime().toString();
//             var newObject = {};
//             if (object) {
//                 newObject = object;
//             }
//             if (scope.tableJson.data.type === 'dynamodb') {
//                 newObject[scope.tableJson.data.key] = date;
//             }
//             for (var i = 0; i < scope.schemaJson.length; i++) {
//                 if (scope.schemaJson[i].defaultByTimestamp) {
//                     newObject[scope.schemaJson[i].field] = date;
//                 } else if (scope.schemaJson[i].default) {
//                     newObject[scope.schemaJson[i].field] = scope.schemaJson[i].default;
//                 }
//             }
//             if (filter) {
//                 filter.data.push(date);
//                 newObject[filter.key] = date;
//             }
//             scope.gridOptions.api.updateRowData({add: [newObject], addIndex: 0});
//             scope.gridOptions.api.refreshInMemoryRowModel();
//             scope.gridOptions.api.getModel().rowsToDisplay[0].edited = true;            

//     }

//     scope.remove = function () {
//         var nodes = scope.gridOptions.api.getSelectedNodes();
//         for (var i = 0; i < nodes.length; i++) {
//             nodes[i].deleted = true;
//         }
//         scope.gridOptions.api.onFilterChanged();
//     }

//     scope.refresh = function () {
//         console.log('Refresh');
//         scope.loadCell(scope.schemaJson).then(function () {
//             scope.gridOptions.api.setColumnDefs(scope.schemaJson);
//         });
//         scope.loadData().then(function (json) {
//             scope.gridOptions.api.setRowData(json);
//         });
//     }

//     scope.isFirstColumn = function (params) {
//         var displayedColumns = params.columnApi.getAllDisplayedColumns();
//         var scopeIsFirstColumn = displayedColumns[0] === params.column;
//         return scopeIsFirstColumn;
//     }

//     scope.cancel = function () {
//         $mdDialog.hide(scope.lastUpdated);
//     }

//     scope.save = function () {
//         return new Promise(function (resolve, reject) {
//             scope.saveSchema();
//             scope.getData().then(function (result) {
//                 scope.saveData(result).then(function () {
//                     $dazzlePopup.toast('儲存成功');
//                     resolve(result);
//                 });
//             });
//         });
//     }

//     scope.saveSchema = function () {
//         var newShcema = [];
//         var oldSchema = scope.gridOptions.columnApi.getAllGridColumns();
//         for (var i = 0; i < oldSchema.length; i++) {
//             oldSchema[i].colDef.width = oldSchema[i].actualWidth;
//             for (var obj in oldSchema[i].colDef) {
//                 if (obj !== 'headerCheckboxSelection' && obj !== 'checkboxSelection' && Object.prototype.toString.call(oldSchema[i].colDef[obj]) == '[object Function]') {
//                     delete oldSchema[i].colDef[obj];
//                 }
//             }
//             newShcema.push(oldSchema[i].colDef);
//         }
//         $dazzleS3.saveJson('dazzle-user-' + $dazzleUser.getUser().uid, "website/" + website + "/content/" + scope.table + "-schema.json", JSON.parse(angular.toJson(newShcema)));
//         scope.schemaJson = newShcema;
//     }

//     scope.saveData = function (data) {
//         return new Promise(function (resolve, reject) {
//             console.log(data);
//             if (scope.tableJson.data.type === 's3') {
//                 console.log('save to s3');
//                 scope.gridOptions.api.removeItems(data.deleted);
//                 $dazzleS3.saveJson('dazzle-user-' + $dazzleUser.getUser().uid, "website/" + website + "/content/" + scope.table + "-data.json", JSON.parse(angular.toJson(data.rows))).then(function () {
//                     resolve();
//                 });
//             } else if (scope.tableJson.data.type === 'dynamodb') {
//                 console.log('save to dynamodb');
//                 var deleted = [];
//                 var edited = [];
//                 for (var i = 0; i < data.deleted.length; i++) {
//                     deleted.push(data.deleted[i].data[scope.tableJson.data.key]);
//                 }
//                 for (var i = 0; i < data.edited.length; i++) {
//                     var dataObject = JSON.parse(angular.toJson(data.edited[i].data));
//                     scope.clean(dataObject);
//                     edited.push(dataObject);
//                 }
//                 scope.lastUpdated = {
//                     deleted: deleted,
//                     edited: edited
//                 };
//                 $http({
//                     "method": "post",
//                     "url": "https://j96d5s2sme.execute-api.ap-northeast-1.amazonaws.com/prod/dynamodb",
//                     "data": {
//                         "action": "batchWriteData",
//                         "data": scope.lastUpdated,
//                         "table": scope.tableJson.data.table,
//                         "key": scope.tableJson.data.key,
//                         "awsKey": scope.user.key
//                     }
//                 }).then(function (result) {
//                     if (result.data.code > 0) {
//                         resolve();
//                     } else {
//                         $dazzlePopup.toast(result.data.text + ":" + result.data.err.code);
//                         reject();
//                     }
//                 });
//             }
//         })
//     }

//     scope.getData = function () {
//         return new Promise(function (resolve, reject) {
//             var nodes = [];
//             var rows = [];
//             var edited = [];
//             var deleted = [];
//             scope.gridOptions.api.forEachNode(function (node) {
//                 nodes.push(node);
//                 if (node.deleted == true) {
//                     deleted.push(node);
//                 } else {
//                     if (node.edited == true) {
//                         edited.push(node);
//                     }
//                     rows.push(node.data);
//                 }
//             });

//             resolve({
//                 "nodes": nodes,
//                 "rows": rows,
//                 "edited": edited,
//                 "deleted": deleted
//             });
//         })
//     }

//     scope.import = function () {
//         if (!scope.fileChooser) {
//             scope.fileChooser = document.createElement('input');
//             scope.fileChooser.setAttribute("type", "file");
//             scope.fileChooser.style.display = "none";
//             scope.fileChooser.addEventListener('change', function (event) {
//                 var file = scope.files[0];
//                 alasql('SELECT * FROM FILE(?,{headers:true})', [event], function (data) {
//                     scope.gridOptions.api.setRowData(data);
//                     scope.gridOptions.api.refreshView();
//                 });
//             });
//         }
//         scope.fileChooser.click();
//     }

//     scope.export = function () {
//         var rowData = [];
//         scope.gridOptions.api.forEachNode(function (node) {
//             rowData.push(node.data);
//         });
//         alasql('SELECT * INTO XLSX("' + scope.table + '.xlsx",{headers:true}) FROM ?', [rowData]);
//     }

//     scope.isObject = function (item) {
//         return (typeof item === "object" && !Array.isArray(item) && item !== null);
//     }

//     scope.clean = function (obj) {
//         for (var propName in obj) {
//             if (obj[propName] === null || obj[propName] === undefined || obj[propName] === '') {
//                 delete obj[propName];
//             }
//         }
//     }



// });
